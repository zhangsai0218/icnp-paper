fileID=fopen('rx.bin','r');
A=fread(fileID,'uint16');
fclose(fileID);
